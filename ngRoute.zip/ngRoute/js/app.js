
var app =angular.module('myApp', ['ngRoute']);
app.config(["$routeProvider", function($routeProvider){
  $routeProvider
    .when('/', {
      template:'<strong> Please click any of the links</strong>'
    })
    .when('/first-msg', {
      templateUrl:'msg1.html',
      controller:'msg1Controller'
    })
    .when('/second-msg', {
      templateUrl:'msg2.html',
      controller:'msg2Controller'
    })
    .when('/sumUrl/:a/:b?', {
      templateUrl:'sum.html',
      controller:'sumController'
    })
    .when('/calc/:option?/:a?/:b?', {
      templateUrl:'calc.html',
      controller:'calcController'
    })
    .otherwise({
      template:'<strong> No templates found</strong>'
    })
}]);

app.controller('msg1Controller', function($scope){
  $scope.a = 10;
  $scope.b = 20;
});

app.controller('msg2Controller', function($scope){
  $scope.c = 30;
  $scope.d = 40;
});

app.controller('sumController', function($scope,$routeParams)
{
  $scope.x = $routeParams.a;
  $scope.y = $routeParams.b;
});

app.controller('calcController', function($scope,dataService,$location,$routeParams){
  console.log("in controller");

  $scope.a = 0;
  $scope.b = 0;

  if($routeParams.a){
    $scope.a = $routeParams.a;
  }

  if($routeParams.b){
    $scope.b = $routeParams.b;
  }

  if($routeParams.option && $routeParams.a && $routeParams.b){
    if($routeParams.option == "add"){
      console.log("Service call Starated");
      dataService.add($scope.a, $scope.b).then(function(result){
        $scope.result = result;
        console.log("Service call Completed");
      });
    }
    else{
      $location.url('/calc');
    }
  }
  $scope.doAdd = function()
  {
    var path = '/calc/add/' + $scope.a + '/' +$scope.b;
    $location.url(path);
  //  dataService.add($scope.a, $scope.b).then(function(result)
   // {
     // $scope.result = result;

  //  });
  }
});

 