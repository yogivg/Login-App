app.config(function(dataServiceProvider){
    dataServiceProvider.config('http://localhost:80/api');
});

app.provider("dataService", function(){

    var baseUrl = '';
    this.config = function(url){
        baseUrl = url;
    };

    this.$get = function($http,$log){
        var odataService = {};

        odataService.add = function(a,b){
            return $http({
                url:baseUrl+'/add/'+ a +'/' + b,
                method: 'GET'

            });
        }
        return odataService;
    };
});